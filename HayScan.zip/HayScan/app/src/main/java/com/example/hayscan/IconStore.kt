package com.example.hayscan

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Stores icon thumbnails: known/<Name>.png (named by you) and unknown/Unknown-N.png (waiting for a name). */
class IconStore(ctx: Context) {
    class Entry(val name: String, val known: Boolean, val vec: FloatArray)

    private val knownDir = File(ctx.filesDir, "known").apply { mkdirs() }
    private val unknownDir = File(ctx.filesDir, "unknown").apply { mkdirs() }
    val entries = ArrayList<Entry>()

    init { reload() }

    fun reload() {
        entries.clear()
        load(knownDir, true)
        load(unknownDir, false)
    }

    private fun load(dir: File, known: Boolean) {
        dir.listFiles()?.forEach { f ->
            BitmapFactory.decodeFile(f.path)?.let {
                val name = if (known) f.nameWithoutExtension.substringBefore('~') else f.nameWithoutExtension
                entries.add(Entry(name, known, vector(it)))
            }
        }
    }

    fun best(v: FloatArray): Pair<Entry, Float>? {
        var b: Entry? = null
        var bd = Float.MAX_VALUE
        for (e in entries) {
            val d = dist(e.vec, v)
            if (d < bd) { bd = d; b = e }
        }
        return b?.let { it to bd }
    }

    fun addUnknown(thumb: Bitmap): Entry {
        val n = "Unknown-" + (System.currentTimeMillis() % 1000000)
        val t = normalize(thumb)
        FileOutputStream(File(unknownDir, "$n.png")).use { t.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val e = Entry(n, false, vector(t))
        entries.add(e)
        return e
    }

    fun unknownFiles(): List<File> = unknownDir.listFiles()?.sortedBy { it.name } ?: emptyList()

    fun promote(f: File, name: String) {
        val clean = name.replace(Regex("[^A-Za-z0-9 _-]"), "_")
        var t = File(knownDir, "$clean.png")
        var i = 2
        while (t.exists()) { t = File(knownDir, "$clean~$i.png"); i++ }
        f.renameTo(t)
    }

    companion object {
        const val NORM = 48
        const val SIZE = 24

        fun normalize(b: Bitmap): Bitmap = Bitmap.createScaledBitmap(b, NORM, NORM, true)

        fun vector(b: Bitmap): FloatArray {
            val s = Bitmap.createScaledBitmap(b, SIZE, SIZE, true)
            val px = IntArray(SIZE * SIZE)
            s.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
            val v = FloatArray(SIZE * SIZE * 3)
            for (i in px.indices) {
                v[i * 3] = Color.red(px[i]) / 255f
                v[i * 3 + 1] = Color.green(px[i]) / 255f
                v[i * 3 + 2] = Color.blue(px[i]) / 255f
            }
            return v
        }

        fun dist(a: FloatArray, b: FloatArray): Float {
            var s = 0f
            for (i in a.indices) s += abs(a[i] - b[i])
            return s / a.size
        }
    }
}
