package com.example.hayscan

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Reads the Hay Day storage grid. All layout numbers are fractions of the screen HEIGHT,
 * measured from a 2400x1080 screenshot, with the panel centred horizontally.
 * Tune the constants below if your phone's layout differs.
 */
class Analyzer(private val store: IconStore) {
    data class Item(val name: String, val qty: Int, val known: Boolean)

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    companion object {
        const val MATCH_THRESHOLD = 0.10f   // lower = stricter icon matching
        // grid area (relative to screen centre-x / height)
        const val GRID_HALF_W = 0.62f
        const val GRID_TOP = 0.25f
        const val GRID_BOTTOM = 0.78f
        // icon rectangle relative to the quantity number's bounding box
        const val ICON_W = 0.105f
        const val ICON_UP = 0.055f
        const val ICON_DOWN = 0.040f
        const val ROW_PITCH = 0.087f
    }

    fun analyze(full: Bitmap): List<Item> {
        store.reload()
        val h = full.height.toFloat()
        val cx = full.width / 2f
        val gl = max(0, (cx - GRID_HALF_W * h).toInt())
        val gr = min(full.width, (cx + GRID_HALF_W * h).toInt())
        val gt = (GRID_TOP * h).toInt()
        val gb = min(full.height, (GRID_BOTTOM * h).toInt())
        val grid = Bitmap.createBitmap(full, gl, gt, gr - gl, gb - gt)

        val text = Tasks.await(recognizer.process(InputImage.fromBitmap(grid, 0)))

        val nums = ArrayList<Pair<Rect, Int>>()
        for (block in text.textBlocks) for (line in block.lines) for (el in line.elements) {
            val s = el.text.replace(",", "").replace(" ", "")
            if (s.matches(Regex("\\d{1,5}"))) {
                val bb = el.boundingBox ?: continue
                val r = Rect(bb)
                r.offset(gl, gt)
                nums.add(r to s.toInt())
            }
        }

        val sorted = nums.sortedWith(
            compareBy({ (it.first.centerY() / (ROW_PITCH * h)).roundToInt() }, { it.first.right })
        )

        val out = ArrayList<Item>()
        for ((r, qty) in sorted) {
            val right = (r.right + 0.006f * h).toInt()
            val left = (right - ICON_W * h).toInt()
            val top = (r.centerY() - ICON_UP * h).toInt()
            val bottom = (r.centerY() + ICON_DOWN * h).toInt()
            // compare only the left 55% of the icon so the quantity digits don't affect matching
            val cmpRight = left + ((right - left) * 0.55f).toInt()
            val l = max(0, left)
            val t = max(0, top)
            val rr = min(full.width, cmpRight)
            val bb = min(full.height, bottom)
            if (rr - l < 8 || bb - t < 8) continue

            val region = Bitmap.createBitmap(full, l, t, rr - l, bb - t)
            val v = IconStore.vector(IconStore.normalize(region))
            val best = store.best(v)
            val entry = if (best != null && best.second < MATCH_THRESHOLD) best.first else store.addUnknown(region)
            out.add(Item(entry.name, qty, entry.known))
        }
        return out
    }
}
