package com.example.hayscan

import android.app.Activity
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Name each unknown icon once; it is remembered forever. */
class TeachActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val store = IconStore(this)
        val files = store.unknownFiles()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = if (files.isEmpty()) "No unknown icons. Scan the barn first."
            else "Type the item name for each icon, then tap Save."
        })
        for (f in files) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            row.addView(ImageView(this).apply { setImageBitmap(BitmapFactory.decodeFile(f.path)) },
                LinearLayout.LayoutParams(dp(64), dp(64)))
            val et = EditText(this).apply { hint = "Item name"; setSingleLine() }
            row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "Save"
                setOnClickListener {
                    val n = et.text.toString().trim()
                    if (n.isNotEmpty()) { store.promote(f, n); render() }
                }
            })
            root.addView(row)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
