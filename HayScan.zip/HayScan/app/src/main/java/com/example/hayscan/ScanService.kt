package com.example.hayscan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import java.util.concurrent.Executors
import kotlin.math.abs

class ScanService : Service() {
    companion object {
        const val ACTION_STOP = "hayscan.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
    }

    private lateinit var wm: WindowManager
    private lateinit var store: IconStore
    private lateinit var analyzer: Analyzer
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    @Volatile private var wantCapture = false

    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val session = LinkedHashMap<String, Analyzer.Item>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = IconStore(this)
        analyzer = Analyzer(store)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startAsForeground()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
        }, handler)
        projection = p
        startCapture()
        addBubble()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("scan", "HayScan", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, ScanService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "scan")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("HayScan is running")
            .setContentText("Open Hay Day and tap the camera bubble")
            .addAction(0, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- screen capture ----------

    private fun realMetrics(): DisplayMetrics {
        val m = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return m
    }

    private fun newReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2).also { r ->
            r.setOnImageAvailableListener({ rd ->
                val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
                if (wantCapture) {
                    wantCapture = false
                    val bmp = try { toBitmap(img) } finally { img.close() }
                    process(bmp)
                } else {
                    img.close()
                }
            }, handler)
        }

    private fun startCapture() {
        val m = realMetrics()
        val r = newReader(m.widthPixels, m.heightPixels)
        reader = r
        // Android 14: create the VirtualDisplay ONCE and keep it; only resize on rotation.
        vdisplay = projection!!.createVirtualDisplay(
            "hayscan", m.widthPixels, m.heightPixels, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val d = vdisplay ?: return
        val m = realMetrics()
        val old = reader
        val nr = newReader(m.widthPixels, m.heightPixels)
        d.resize(m.widthPixels, m.heightPixels, m.densityDpi)
        d.surface = nr.surface
        reader = nr
        old?.close()
        hidePanel()
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * img.width
        val tmp = Bitmap.createBitmap(img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        tmp.copyPixelsFromBuffer(p.buffer)
        return Bitmap.createBitmap(tmp, 0, 0, img.width, img.height)
    }

    private fun scan() {
        hidePanel()
        bubble?.visibility = View.INVISIBLE      // keep the bubble out of the screenshot
        handler.postDelayed({ wantCapture = true }, 350)
        handler.postDelayed({
            if (wantCapture) {
                wantCapture = false
                bubble?.visibility = View.VISIBLE
                toast("No frame captured, try again")
            }
        }, 3000)
    }

    private fun process(bmp: Bitmap) {
        worker.execute {
            val res = try { analyzer.analyze(bmp) } catch (e: Exception) { null }
            handler.post {
                bubble?.visibility = View.VISIBLE
                if (res == null) {
                    toast("Scan failed")
                } else {
                    for (item in res) session[item.name] = item
                    showPanel()
                }
            }
        }
    }

    // ---------- overlay UI ----------

    private fun addBubble() {
        val b = TextView(this).apply {
            text = "📷"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCCE65100.toInt()) }
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) scan(); true }
                else -> false
            }
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun sortedItems() = session.values.sortedByDescending { it.qty }

    private fun render(): String {
        val list = sortedItems()
        if (list.isEmpty()) return "Nothing found. Open the Barn/Silo storage screen and tap the bubble."
        return "${list.size} items (scroll the barn and scan again to add more)\n\n" +
            list.joinToString("\n") { (if (it.known) it.name else "❓ " + it.name) + " – " + it.qty }
    }

    private fun showPanel() {
        hidePanel()
        val m = resources.displayMetrics
        val w = minOf((m.widthPixels * 0.8f).toInt(), dp(360))
        val h = (m.heightPixels * 0.7f).toInt()

        val txt = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f
            setPadding(dp(12), dp(8), dp(12), dp(8)); text = render()
        }
        val scroll = ScrollView(this).apply { addView(txt) }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 12f
            minWidth = 0; minimumWidth = 0
            setOnClickListener { onClick() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            addView(btn("Copy") { copy() }, lp())
            addView(btn("Clear") { session.clear(); txt.text = render() }, lp())
            addView(btn("Teach") {
                startActivity(Intent(this@ScanService, TeachActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, lp())
            addView(btn("Hide") { hidePanel() }, lp())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xEE222222.toInt()); cornerRadius = dp(12).toFloat() }
            addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(row)
        }
        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(8) }
        wm.addView(root, lp)
        panel = root
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun copy() {
        val text = sortedItems().joinToString("\n") { it.name + " – " + it.qty }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("hayscan", text))
        toast("Copied")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        vdisplay?.release()
        reader?.close()
        val p = projection
        projection = null
        p?.stop()
        worker.shutdown()
        super.onDestroy()
    }
}
