package com.example.hayscan

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScanService::class.java)
                .putExtra(ScanService.EXTRA_CODE, r.resultCode)
                .putExtra(ScanService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "Open Hay Day, go to the Barn, tap the 📷 bubble", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }

    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { askCapture() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "HayScan reads the Hay Day Barn/Silo screen and lists every item with its quantity.\n\n" +
                "1. Start the scanner (allow overlay + screen capture)\n" +
                "2. Open Hay Day > Barn, tap the 📷 bubble\n" +
                "3. First time only: tap Teach and name each icon once\n"
        })
        fun btn(label: String, f: () -> Unit) = root.addView(Button(this).apply {
            text = label; isAllCaps = false; setOnClickListener { f() }
        })
        btn("Start scanner") { start() }
        btn("Teach icons") { startActivity(Intent(this, TeachActivity::class.java)) }
        btn("Stop scanner") { startService(Intent(this, ScanService::class.java).setAction(ScanService.ACTION_STOP)) }
        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'display over other apps' for HayScan, then come back", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            askCapture()
        }
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        capture.launch(mpm.createScreenCaptureIntent())
    }
}
