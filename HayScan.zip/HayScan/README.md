# HayScan
Kotlin + ML Kit OCR + on-device icon matching. Reads the Hay Day Barn/Silo grid and lists item -> quantity.

## Build the APK
A) Android Studio: File > Open this folder > wait for sync > Build > Build APK(s).
   APK: app/build/outputs/apk/debug/app-debug.apk
B) No Android Studio: push this folder to a GitHub repo; Actions > "Build APK" > download artifact.

## Use
1. Install, open HayScan, tap Start scanner (allow overlay, notifications, screen capture).
2. Open Hay Day > Barn. Tap the camera bubble.
3. First time: items show as "Unknown-xxxx". Tap Teach and name each icon once.
4. Scroll the barn and scan again to add more; results merge. Copy exports "Item - qty" lines.

## Tuning
If the quantities/icons are misread on your phone, adjust constants in Analyzer.kt
(grid position, icon size, MATCH_THRESHOLD).
